from abc import ABC, abstractmethod
from typing import Tuple

import torch
from torch import nn
import numpy as np

class Regularizer(nn.Module, ABC):
    @abstractmethod
    def forward(self, factors: Tuple[torch.Tensor]):
        pass

def givens_rotations(x, r):
    givens = r.view((r.shape[0], -1, 2))
    givens = givens / torch.norm(givens, p=2, dim=-1, keepdim=True)
    x = x.view((r.shape[0], -1, 2))
    x_rot = givens[:, :, 0:1] * x + givens[:, :, 1:] * torch.cat((-x[:, :, 1:], x[:, :, 0:1]), dim=-1)
    return x_rot.view((r.shape[0], -1))

class Fro(Regularizer):
    def __init__(self, weight: float):
        super(Fro, self).__init__()
        self.weight = weight

    def forward(self, factors):
        norm = 0
        for factor in factors:
            for f in factor:
                norm += self.weight * torch.sum(
                    torch.norm(f, 2) ** 2
                )
        return norm / factors[0][0].shape[0]


class N3(Regularizer):
    def __init__(self, weight: float):
        super(N3, self).__init__()
        self.weight = weight

    def forward(self, factors):
        norm = 0
        for factor in factors:
            for f in factor:
                norm += self.weight * torch.sum(
                    torch.abs(f) ** 3
                ) / f.shape[0]
        return norm


class L2(Regularizer):
    def __init__(self, weight: float):
        super(L2, self).__init__()
        self.weight = weight

    def forward(self, factors):
        norm = 0
        for factor in factors:
            for f in factor:
                norm += self.weight * torch.sum(
                    torch.abs(f) ** 2
                )
        return norm / factors[0][0].shape[0]


class L1(Regularizer):
    def __init__(self, weight: float):
        super(L1, self).__init__()
        self.weight = weight

    def forward(self, factors):
        norm = 0
        for factor in factors:
            for f in factor:
                norm += self.weight * torch.sum(
                    torch.abs(f)**1
                )
        return norm / factors[0][0].shape[0]


class NA(Regularizer):
    def __init__(self, weight: float):
        super(NA, self).__init__()
        self.weight = weight

    def forward(self, factors):
        return torch.Tensor([0.0]).cuda()

class ER(Regularizer):
    def __init__(self, weight: float):
        super(ER, self).__init__()
        self.weight = weight

    def forward(self, factors):
        norm = 0
        a=1.02;b=1#can be adjusted

        for factor in factors:
            h, r, t = factor
            norm += torch.sum(torch.abs(t)**2 + torch.abs(h)**2)
            t=torch.abs(t);h=torch.abs(h);r=torch.abs(r)
            norm += torch.sum(a*torch.abs(h)**2 * torch.abs(r)**2 +a*2*torch.abs(h) * torch.abs(r)*+ a*torch.abs(t)**2 * torch.abs(r)**2+b*torch.abs(h)**2 * torch.abs(r)**2 -b*2*torch.abs(h) * torch.abs(r)*+ b*torch.abs(t)**2 * torch.abs(r)**2)

        return self.weight * norm / h.shape[0]


class ER_RESCAL(Regularizer):
    def __init__(self, weight: float):
        super(ER_RESCAL, self).__init__()
        self.weight = weight

    def forward(self, factors):
        norm = 0
        a=1;b=1.02# can be adjusted
        for factor in factors:
            h, r, t = factor
            norm += torch.sum(h ** 2 + t** 2)
            norm += torch.sum(
                a*torch.bmm(r.transpose(1, 2),h.unsqueeze(-1))**2+2*a*torch.bmm(r.transpose(1, 2),h.unsqueeze(-1))*torch.bmm(r, t.unsqueeze(-1))+a*torch.bmm(r, t.unsqueeze(-1)) **2+ b*torch.bmm(r.transpose(1, 2),h.unsqueeze(-1))**2-2*b*torch.bmm(r.transpose(1, 2),h.unsqueeze(-1))*torch.bmm(r, t.unsqueeze(-1))+b*torch.bmm(r, t.unsqueeze(-1)) **2)
        return self.weight * norm / h.shape[0]
